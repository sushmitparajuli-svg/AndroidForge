# Malta Payslip Calculator — Android Studio project

## Open and run
1. Extract the ZIP archive.
2. Open **Android Studio** > **Open** and select the `malta_payslip_android` folder (the folder containing `settings.gradle`).
3. Allow Android Studio to download/sync Android Gradle Plugin 8.7.3, Gradle 8.9 and Android SDK Platform 35 if prompted. Use JDK 17.
4. Connect an Android phone with USB debugging enabled, or select an Android emulator.
5. Click **Run ▶** to install and launch the app.

## Build an APK
In Android Studio, select **Build > Build Bundle(s) / APK(s) > Build APK(s)** (menu wording varies by version). Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk` after a successful build. You can copy that APK to an Android phone and install it after allowing installation from the chosen source.

## Project details
- App ID: `com.example.maltapayslip`
- Java Android Activity hosting a bundled offline HTML/JavaScript calculator.
- `app/src/main/assets/index.html` is the calculator UI and business logic; edit this file to change calculations.
- Saves entered data locally through WebView localStorage. Removing app data/uninstalling may erase saved entries; export backups where offered.
- No internet permission is required.

## Important
The salary, tax, National Insurance and FS3 values are **estimates**, not an official Malta payroll or tax assessment. Confirm eligibility for any special tax treatment and verify tax bands and SSC rules for the relevant year. The supplied 2026 Additional Balance Pay period dates are based on the user's calendar; review them before relying on a payslip.

This archive contains source code, not a prebuilt APK. An APK must be built using Android Studio.
